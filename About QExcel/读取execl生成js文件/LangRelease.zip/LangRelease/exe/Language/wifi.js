LangM.push({
'1':'APPLY',
'2':'good',
'3':'enable',
'4':'',
'5':'22',
"":null});
