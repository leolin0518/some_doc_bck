LangM.push({
'1':'APPLY',
'2':'up',
"":null});
