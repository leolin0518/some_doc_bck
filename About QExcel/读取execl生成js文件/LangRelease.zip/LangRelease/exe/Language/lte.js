LangM.push({
'1':'APPLY',
'2':'good',
'3':'enable',
'4':'Login Username ',
'5':'Login Timeout',
'6':'Login name ',
"":null});
